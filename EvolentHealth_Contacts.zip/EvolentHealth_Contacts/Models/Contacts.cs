﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace EvolentHealth_Contacts.Models
{
    [MetadataType(typeof(ContactMetadata))]
    public partial class Contact
    {
        
    }

    public class ContactMetadata
    {
        [Required]
        public int ContactID { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string PhoneNumber { get; set; }
        [Required]
        public string Status { get; set; }
    }
}