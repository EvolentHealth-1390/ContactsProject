﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EvolentHealth_Contacts.Startup))]
namespace EvolentHealth_Contacts
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
